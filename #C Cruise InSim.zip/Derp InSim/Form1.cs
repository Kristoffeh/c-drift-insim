using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InSimDotNet;
using InSimDotNet.Packets;
using System.Globalization;
using System.Threading;
using InSimDotNet.Helpers;
using System.IO;

namespace Derp_InSim
{
    public partial class Form1 : Form
    {
        InSim insim = new InSim();
        
        // Global Vars
        //public const string Tag = "^5EC^0�";
        public const string InSimVersion = "0.4a";
        const string AVAILABLE_CARS = "UF1+XFG+XRG+LX4+LX6+RB4+FXO+XRT+RAC+FZ5+UFR+XFR+FXR+XRR+FZR+MRT+FBM+FOX+FO8+BF1";

        public string TrackName = "None";
        public string HostName = "host";
        public string LayoutName = "None";
        public int dbCount = 0;

        // MySQL Variables
        public SQLInfo SqlInfo = new SQLInfo();
        public bool ConnectedToSQL = false;
        public int SQLRetries = 0;

        // MySQL Connect
        string SQLIPAddress = "127.0.0.1"; // 93.190.143.115
        string SQLDatabase = "lfs";
        string SQLUsername = "root";
        string SQLPassword = "1997andre";

        public bool AskedPosition = false;
        public byte AskedPosUCID = 255;

        class Connections
        {
            // NCN fields
            public byte UCID;
            public string UName;
            public string PName;
            public bool IsAdmin;

            // Custom Fields
            public bool IsSuperAdmin;
            
            public bool OnTrack;

            // public byte Interface;
            public bool DisplaysOpen;
            public int InShopDist;
            public bool InShop;

            public int cash;
            public int bankbalance;
            public string regdate;
            public string lastseen;
            public int totaljobsdone;
            public int totalearnedfromjobs;
            public string cars;

            public string bandate;
            public string banreason;

            public string DateTime;
            public int Timezone;

            public long TotalDistance;
            public long Trip;
            public int _todayscash;
            public int _initialcash;

            public string CurrentCar = "None";

            public int TodaysCash
            {
                get { return _todayscash; }
                set { _todayscash = value; }
            }

            public int InitialCash
            {
                get { return _initialcash; }
                set { _initialcash = value; }
            }

        }
        class Players
        {
            public byte UCID;
            public byte PLID;
            public string PName;
            public string CName;

            public int kmh;
            public int mph;
            public string Plate;
        }

        private Dictionary<byte, Connections> _connections = new Dictionary<byte, Connections>();
        private Dictionary<byte, Players> _players = new Dictionary<byte, Players>();

        public Form1()
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-US");

            InitializeComponent();
            RunInSim();
        }

        void RunInSim()
        {

            // Bind packet events.
            insim.Bind<IS_NCN>(NewConnection);
            insim.Bind<IS_NPL>(NewPlayer);
            insim.Bind<IS_MSO>(MessageReceived);
            insim.Bind<IS_MCI>(MultiCarInfo);
            insim.Bind<IS_CNL>(ConnectionLeave);
            insim.Bind<IS_CPR>(ClientRenames);
            insim.Bind<IS_PLL>(PlayerLeave);
            insim.Bind<IS_STA>(OnStateChange);
            insim.Bind<IS_BTC>(ButtonClicked);
            insim.Bind<IS_BFN>(ClearButtons);
            insim.Bind<IS_VTN>(VoteNotify);
            insim.Bind<IS_AXI>(OnAutocrossInformation);
            insim.Bind<IS_TINY>(OnTinyReceived);

            // Initialize InSim
            insim.Initialize(new InSimSettings
            {
                Host = "93.190.143.115", // 93.190.143.115
                Port = 29997,
                Admin = "29echso10",
                Prefix = '!',
                Flags = InSimFlags.ISF_MCI | InSimFlags.ISF_MSO_COLS,

                Interval = 1000
            });

            insim.Send(new[]
            {
                new IS_TINY { SubT = TinyType.TINY_NCN, ReqI = 255 },
                new IS_TINY { SubT = TinyType.TINY_NPL, ReqI = 255 },
                new IS_TINY { SubT = TinyType.TINY_ISM, ReqI = 255 },
                new IS_TINY { SubT = TinyType.TINY_SST, ReqI = 255 },
                new IS_TINY { SubT = TinyType.TINY_MCI, ReqI = 255 },
                new IS_TINY { SubT = TinyType.TINY_NCI, ReqI = 255 },
                new IS_TINY { SubT = TinyType.TINY_AXI, ReqI = 255 },
                new IS_TINY { SubT = TinyType.TINY_SST, ReqI = 255 },
                });

            insim.Send("/cars " + AVAILABLE_CARS);
            insim.Send(255, 0, "^3NOTE: ^8InSim connected with version ^2" + InSimVersion);

            ConnectedToSQL = SqlInfo.StartUp(SQLIPAddress, SQLDatabase, SQLUsername, SQLPassword);
            if (!ConnectedToSQL)
            {
                insim.Send(255, "SQL connect attempt failed! Attempting to reconnect in ^310 ^8seconds!");
                SQLReconnectTimer.Start();
            }
            else insim.Send(255, "SQL Connected!");
        }

        #region ' Misc '

        bool TryParseCommand(IS_MSO mso, out string[] args)
        {
            if (mso.UserType == UserType.MSO_PREFIX)
            {
                var message = mso.Msg.Substring(mso.TextStart);
                args = message.Split();
                return args.Length > 0;
            }

            args = null;
            return false;
        }

        /// <summary>Returns true if method needs invoking due to threading</summary>
        private bool DoInvoke()
        {
            foreach (Control c in this.Controls)
            {
                if (c.InvokeRequired) return true;
                break;	// 1 control is enough
            }
            return false;
        }
        #endregion

        // Player joins server
        void NewConnection(InSim insim, IS_NCN packet)
        {
            try
            {
                _connections.Add(packet.UCID, new Connections
                {
                    UCID = packet.UCID,
                    UName = packet.UName,
                    PName = packet.PName,
                    IsAdmin = packet.Admin,

                    IsSuperAdmin = GetUserAdmin(packet.UName),
                    OnTrack = false,
                    TotalDistance = 0,
                    cash = 17500,
                    bankbalance = 1000,
                    cars = "UF1 XFG XRG",
                    InitialCash = 0,
                    TodaysCash = 0,
                    DisplaysOpen = false,
                    InShop = false,
                    InShopDist = 0,
                    DateTime = "" + DateTime.UtcNow.Hour + DateTime.UtcNow.Minute,
                    Timezone = 0,
                    bandate = "",
                    banreason = "",
                });

                if (ConnectedToSQL && packet.UName != "")
                {
                    try
                    {
                        if (SqlInfo.UserExist(packet.UName))
                        {
                            
                            SqlInfo.UpdateUser(packet.UName, true);//Updates the last joined time to the current one

                            string[] LoadedOptions = SqlInfo.LoadUserOptions(packet.UName);
                            _connections[packet.UCID].cash = Convert.ToInt32(LoadedOptions[0]);
                            _connections[packet.UCID].bankbalance = Convert.ToInt32(LoadedOptions[1]);
                            _connections[packet.UCID].TotalDistance = Convert.ToInt32(LoadedOptions[2]);
                            _connections[packet.UCID].cars = LoadedOptions[3];
                            _connections[packet.UCID].regdate = LoadedOptions[4];
                            _connections[packet.UCID].lastseen = LoadedOptions[5];
                            _connections[packet.UCID].totaljobsdone = Convert.ToInt32(LoadedOptions[6]);
                            _connections[packet.UCID].totalearnedfromjobs = Convert.ToInt32(LoadedOptions[7]);
                            _connections[packet.UCID].Timezone = Convert.ToInt32(LoadedOptions[8]);

                            _connections[packet.UCID].InitialCash = _connections[packet.UCID].cash;
                            _connections[packet.UCID].Trip = _connections[packet.UCID].TotalDistance;

                            if (packet.PName != HostName && packet.UCID != 0)
                            {
                                insim.Send(255, "" + packet.PName + " ^8was last seen at ^3" + _connections[packet.UCID].lastseen);
                            }


                        }
                        else
                        {
                            if (packet.PName != HostName && packet.UCID != 0)
                            {
                                insim.Send(255, packet.PName + " ^8(" + packet.UName + ") joined the server for the first time!");
                            }
                            SqlInfo.AddUser(packet.UName, _connections[packet.UCID].cash, _connections[packet.UCID].bankbalance, _connections[packet.UCID].TotalDistance, _connections[packet.UCID].cars, _connections[packet.UCID].totaljobsdone, _connections[packet.UCID].totalearnedfromjobs, _connections[packet.UCID].Timezone);
                        }

                        CheckCars(packet.UCID);
                        UpdateGui(packet.UCID, true, true, true);

                        dbCount = SqlInfo.userCount();

                    }
                    catch (Exception EX)
                    {
                        if (!SqlInfo.IsConnectionStillAlive())
                        {
                            ConnectedToSQL = false;
                            SQLReconnectTimer.Start();
                        }
                        LogTextToFile("sqlerror", "[" + packet.UCID + "] " + StringHelper.StripColors(packet.PName) + "(" + packet.UName + ") NCN - Exception: " + EX, false);
                    }
                }

                #region ' Retrieve HostName '
                if (packet.UCID == 0 && packet.UName == "")
                {
                    HostName = packet.PName;
                }
                #endregion
            }
            catch (Exception e) { LogTextToFile("error", "[" + packet.UCID + "] " + StringHelper.StripColors(packet.PName) + "(" + packet.UName + ") NCN - Exception: " + e.Message, false); }
        }


        // Player joins race or enter track
        void NewPlayer(InSim insim, IS_NPL packet)
        {
            try
            {
                if (_players.ContainsKey(packet.PLID))
                {
                    // Leaving pits, just update NPL object.
                    _players[packet.PLID].UCID = packet.UCID;
                    _players[packet.PLID].PLID = packet.PLID;
                    _players[packet.PLID].PName = packet.PName;
                    _players[packet.PLID].CName = packet.CName;
                    _players[packet.PLID].Plate = packet.Plate;
                }
                else
                {
                    // Add new player.
                    _players.Add(packet.PLID, new Players
                    {
                        UCID = packet.UCID,
                        PLID = packet.PLID,
                        PName = packet.PName,
                        CName = packet.CName,
                        Plate = packet.Plate
                    });
                }

                Connections CurrentConnection = GetConnection(packet.PLID);

                bool StoleThisCar = CheckCars(CurrentConnection.UCID);
                if (StoleThisCar)
                {
                    insim.Send(255, "^8" + CurrentConnection.PName + " ^8tried to steal a ^1" + packet.CName);
                    insim.Send("/spec " + _connections[packet.UCID].UName);
                }
                else
                {
                    CurrentConnection.CurrentCar = packet.CName;
                }

            }
            catch (Exception e) { LogTextToFile("error", "[" + packet.UCID + "] " + StringHelper.StripColors(packet.PName) + "(" + GetConnection(packet.PLID).UName + ") NPL - Exception: " + e, false); }
        }

        // Player left the server
        void ConnectionLeave(InSim insim, IS_CNL CNL)
        {
            try
            {
                LogTextToFile("connections", _connections[CNL.UCID].PName + " (" + _connections[CNL.UCID].UName + ") Disconnected", false);

                // Save values of user - CNL (on disconnect)

                if (ConnectedToSQL)
                {
                    try { SqlInfo.UpdateUser(_connections[CNL.UCID].UName, false, _connections[CNL.UCID].cash, _connections[CNL.UCID].bankbalance, _connections[CNL.UCID].TotalDistance, _connections[CNL.UCID].cars, _connections[CNL.UCID].totaljobsdone, _connections[CNL.UCID].totalearnedfromjobs, _connections[CNL.UCID].Timezone); }
                    catch (Exception EX)
                    {
                        if (!SqlInfo.IsConnectionStillAlive())
                        {
                            ConnectedToSQL = false;
                            SQLReconnectTimer.Start();
                        }
                        LogTextToFile("sqlerror", "[" + CNL.UCID + "] " + StringHelper.StripColors(_connections[CNL.UCID].PName) + "(" + _connections[CNL.UCID].UName + ") CNL - Exception: " + EX.Message, false);
                    }
                }

                _connections.Remove(CNL.UCID);
            }
            catch (Exception e) {  LogTextToFile("error", "[" + CNL.UCID + "] " + StringHelper.StripColors(_connections[CNL.UCID].PName) + "(" + _connections[CNL.UCID].UName + ") CNL - Exception: " + e, false); }
        }

        // Button click (is_btn click ID's)
        void ButtonClicked(InSim insim, IS_BTC BTC)
        {
            try { BTC_ClientClickedButton(BTC); }
            catch (Exception e) { LogTextToFile("error", "[" + BTC.UCID + "] " + StringHelper.StripColors(_connections[BTC.UCID].PName) + "(" + _connections[BTC.UCID].UName + ") BTC - Exception: " + e, false); }
        }

        // BuTton FunctioN (IS_BFN, SHIFT + I)
        void ClearButtons(InSim insim, IS_BFN BFN)
        {
            try { insim.Send(BFN.UCID, "^8InSim buttons cleared ^7(SHIFT + I)"); UpdateGui(BFN.UCID, true, true, true); }
            catch (Exception e)
            { LogTextToFile("error", "[" + BFN.UCID + "] " + StringHelper.StripColors(_connections[BFN.UCID].PName) + "(" + _connections[BFN.UCID].UName + ") BFN - Exception: " + e, false); }
        }

        // Autocross information
        private void OnAutocrossInformation(InSim insim, IS_AXI AXI)
        {
            try
            {
                if (AXI.NumO != 0)
                {
                    LayoutName = AXI.LName;
                    if (AXI.ReqI == 0) insim.Send(255, "Layout loaded");
                }
            }
            catch (Exception EX) { LogTextToFile("error", "AXI - " + EX.Message); }
        }

        // Vote notify (cancel votes)
        private void VoteNotify(InSim insim, IS_VTN VTN)
        {
            try
            {
                foreach (var conn in _connections.Values)
                {
                    if (conn.UCID == VTN.UCID)
                    {
                        if (VTN.Action == VoteAction.VOTE_END)
                        {
                            if (_connections[VTN.UCID].IsAdmin != true)
                            {
                                insim.Send("/cv");
                            }
                        }

                        if (VTN.Action == VoteAction.VOTE_RESTART)
                        {
                            if (_connections[VTN.UCID].IsAdmin != true)
                            {
                                insim.Send("/cv");
                            }
                        }


                    }
                }

            }
            catch (Exception e) { LogTextToFile("error", "[" + VTN.UCID + "] " + StringHelper.StripColors(_connections[VTN.UCID].PName) + "(" + _connections[VTN.UCID].UName + ") - VTN - Exception: " + e, false); }
        }

        // MCI - Multi Car Info
        private void MultiCarInfo(InSim insim, IS_MCI mci)
        {
            try
            {
                {
                    foreach (CompCar car in mci.Info)
                    {
                        Connections conn = GetConnection(car.PLID);

                        int Sped = Convert.ToInt32(MathHelper.SpeedToKph(car.Speed));

                        decimal SpeedMS = (int)(((car.Speed / 32768f) * 100f) / 2);
                        decimal Speed = (int)((car.Speed * (100f / 32768f)) * 3.6f);

                        int kmh = car.Speed / 91;
                        int mph = car.Speed / 146;
                        var X = car.X;
                        var Y = car.Y;
                        var Z = car.Z;
                        var angle = car.AngVel / 30;
                        string anglenew = "";
                        int Angle = AbsoluteAngleDifference(car.Direction, car.Heading);

                        _players[car.PLID].kmh = kmh;
                        _players[car.PLID].mph = mph;

                        conn.TotalDistance += Convert.ToInt32(SpeedMS);

                        if (AskedPosition == true && AskedPosUCID == conn.UCID)
                        {
                            // SendRCMToUsername(CurrentConnection.UName, "Your Position is: " + (car.X / 65535) + ", " + (car.Y / 65535), 5000);//keep the message for 5seconds(5000ms)
                            insim.Send(AskedPosUCID, "^3X: ^7" + (car.X / 65535) + " ^3Y: ^7" + (car.Y / 65535));
                            insim.Send(AskedPosUCID, "^3Speed: ^1" + Speed + " ^3Angle: ^1" + Angle);

                            AskedPosition = false;
                            AskedPosUCID = 255;
                        }

                        /*if (MathHelper.LengthToMeters(MathHelper.Distance(car.X, car.Y, -339, -21)) < 2)
                        if (conn.InShopDist <= 10 && (mph <= 10))
                        {

                            if (conn.InShop == false)
                            {
                                string EstablishmentName = "Mechanics";
                                // insim.Send(conn.UCID, "^8Welcome to the ^2" + EstablishmentName + "!");
                                if (conn.DisplaysOpen == false)
                                {
                                    #region ' Display '

                                    // insim.Send(conn.UCID, "^8Welcome to the ^2" + EstablishmentName + "!");


                                    conn.DisplaysOpen = true;

                                    #endregion
                                }

                                conn.InShop = true;
                            }
                            else
                            {
                                insim.Send(conn.UCID, "^5YOU HAVE OTHER WINDOWS OPENED, CLOSE YOUR WINDOWS AND TRY AGAIN!");
                            }
                        }
                        else
                        {
                            #region ' Close Display '

                            if (conn.InShop== true)
                            {
                                #region ' Close Display '
                                if (conn.DisplaysOpen == true)
                                {
                                    conn.DisplaysOpen = false;
                                }
                                #endregion

                                conn.InShop = false;
                            }

                            #endregion
                        }*/

                        UpdateGui(conn.UCID, false, true);

                        anglenew = angle.ToString().Replace("-", "");
                    }
                }
            }
            catch (Exception e) { LogTextToFile("error", "MCI - Exception: " + e, false); }
        }

        void ClientRenames(InSim insim, IS_CPR CPR)
        {
            try
            {
                _connections[CPR.UCID].PName = CPR.PName;
                foreach (var CurrentPlayer in _players.Values) if (CurrentPlayer.UCID == CPR.UCID) CurrentPlayer.PName = CPR.PName;//make sure your code is AFTER this one
            }
            catch (Exception e) { LogTextToFile("error", "[" + CPR.UCID + "] " + StringHelper.StripColors(CPR.PName) + "(" + _connections[CPR.UCID].UName + ") - CPR - Exception: " + e, false); }
        }

        void OnStateChange(InSim insim, IS_STA STA)
        {
            try
            {
                if (TrackName != STA.Track)
                {
                    TrackName = STA.Track;
                    insim.Send(new IS_TINY { SubT = TinyType.TINY_AXI, ReqI = 255 });
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("" + e, "AN ERROR OCCURED");
                insim.Send(255, "^8An error occured: ^1{0}", e);
            }
        }

        // Join spectators (SHIFT + S)
        void PlayerLeave(InSim insim, IS_PLL PLL)
        {
            try
            {
                Connections conn = GetConnection(PLL.PLID);

                _players.Remove(PLL.PLID);//make sure your code is BEFORE this one
                conn.CurrentCar = "None";

                UpdateGui(conn.UCID, true, true, true);
            }
            catch (Exception e)
            {
                Connections conn = GetConnection(PLL.PLID);
                LogTextToFile("error", "[" + conn.UCID + "] " + StringHelper.StripColors(conn.PName) + "(" + conn.UName + ") - PLL - Exception: " + e, false);
            }
        }



        #region ' Functions '
        void UpdateGui(byte UCID, bool money, bool km, bool main = false)
        {
            const string TimeFormat = "HH:mm";//ex: 23:23 PM

            if (main)
            {
                // DARK
                insim.Send(new IS_BTN
                {
                    UCID = UCID,
                    ReqI = 1,
                    ClickID = 1,
                    BStyle = ButtonStyles.ISB_DARK,
                    H = 8,
                    W = 68,
                    T = 0,
                    L = 63,
                });
            }

            if (money)
            {
                // Cash label
                insim.Send(new IS_BTN
                {
                    Text = "^7Cash:",
                    UCID = UCID,
                    ReqI = 2,
                    ClickID = 2,
                    BStyle = ButtonStyles.ISB_LEFT,
                    H = 4,
                    W = 7,
                    T = 0,
                    L = 64,
                });

                // Cash box
                insim.Send(new IS_BTN
                {
                    Text = "^2�" + string.Format("{0:n0}", _connections[UCID].cash),
                    UCID = UCID,
                    ReqI = 3,
                    ClickID = 3,
                    BStyle = ButtonStyles.ISB_LEFT,
                    H = 4,
                    W = 10,
                    T = 0,
                    L = 70,
                });

                // Session Cash label
                insim.Send(new IS_BTN
                {
                    Text = "^7Today:",
                    UCID = UCID,
                    ReqI = 4,
                    ClickID = 4,
                    BStyle = ButtonStyles.ISB_LEFT,
                    H = 4,
                    W = 7,
                    T = 4,
                    L = 64,
                });

                // Session Cash box
                insim.Send(new IS_BTN
                {
                    Text = "^2�" + string.Format("{0:n0}", (_connections[UCID].cash - _connections[UCID].InitialCash)),
                    UCID = UCID,
                    ReqI = 5,
                    ClickID = 5,
                    BStyle = ButtonStyles.ISB_LEFT,
                    H = 4,
                    W = 10,
                    T = 4,
                    L = 70,
                });
            }

            if (km)
            {
                // label
                insim.Send(new IS_BTN
                {
                    Text = "^7Total distance:",
                    UCID = UCID,
                    ReqI = 6,
                    ClickID = 6,
                    BStyle = ButtonStyles.ISB_LEFT,
                    H = 4,
                    W = 15,
                    T = 0,
                    L = 82,
                });

                // label 2
                insim.Send(new IS_BTN
                {
                    Text = "^7Distance today:",
                    UCID = UCID,
                    ReqI = 7,
                    ClickID = 7,
                    BStyle = ButtonStyles.ISB_LEFT,
                    H = 4,
                    W = 15,
                    T = 4,
                    L = 82,
                });

                // km
                insim.Send(new IS_BTN
                {
                    Text = "^7" + string.Format("{0:n0}", _connections[UCID].TotalDistance / 1000) + " km",
                    UCID = UCID,
                    ReqI = 8,
                    ClickID = 8,
                    BStyle = ButtonStyles.ISB_LEFT,
                    H = 4,
                    W = 12,
                    T = 0,
                    L = 96,
                });

                // todays km
                insim.Send(new IS_BTN
                {
                    Text = "^7" + string.Format("{0:n0}", (_connections[UCID].TotalDistance - _connections[UCID].Trip) / 1000) + " km",
                    UCID = UCID,
                    ReqI = 9,
                    ClickID = 9,
                    BStyle = ButtonStyles.ISB_LEFT,
                    H = 4,
                    W = 12,
                    T = 4,
                    L = 96,
                });
            }

            // Vehicle label
            insim.Send(new IS_BTN
            {
                Text = "^7Vehicle (" + _connections[UCID].CurrentCar + "):",
                UCID = UCID,
                ReqI = 10,
                ClickID = 10,
                BStyle = ButtonStyles.ISB_LEFT,
                H = 4,
                W = 13,
                T = 4,
                L = 110,
            });

            // Vehicle value
            insim.Send(new IS_BTN
            {
                Text = "^710%",
                UCID = UCID,
                ReqI = 14,
                ClickID = 14,
                BStyle = ButtonStyles.ISB_LEFT,
                H = 4,
                W = 8,
                T = 4,
                L = 123,
            });

            if (_connections[UCID].Timezone == -12)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-12).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -11)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-11).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -10)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-10).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -9)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-9).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -8)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-8).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -7)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-7).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -6)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-6).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -5)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-5).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -4)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-4).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -3)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-3).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -2)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-2).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == -1)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(-1).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 0)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(0).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 1)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(1).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 2)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(2).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 3)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(3).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 4)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(4).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 5)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(5).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 6)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(6).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 7)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(7).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 8)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(8).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 9)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(9).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 10)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(10).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 11)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(11).ToString(TimeFormat);
            }
            else if (_connections[UCID].Timezone == 12)
            {
                _connections[UCID].DateTime = DateTime.UtcNow.AddHours(12).ToString(TimeFormat);
            }
            


            // Datetime
            insim.Send(new IS_BTN
            {
                Text = "^7" + _connections[UCID].DateTime,
                UCID = UCID,
                ReqI = 11,
                ClickID = 11,
                BStyle = ButtonStyles.ISB_LEFT,
                H = 4,
                W = 20, // 6
                T = 0,
                L = 123,
            });

            // Total Jobs label
            insim.Send(new IS_BTN
            {
                Text = "^7Jobs:",
                UCID = UCID,
                ReqI = 12,
                ClickID = 12,
                BStyle = ButtonStyles.ISB_LEFT,
                H = 4,
                W = 6,
                T = 0,
                L = 110,
            });

            // Total Jobs
            insim.Send(new IS_BTN
            {
                Text = "^7" + string.Format("{0:n0}", _connections[UCID].totaljobsdone),
                UCID = UCID,
                ReqI = 13,
                ClickID = 13,
                BStyle = ButtonStyles.ISB_LEFT,
                H = 4,
                W = 6,
                T = 0,
                L = 115,
            });
        }

        private void OnTinyReceived(InSim insim, IS_TINY TINY)
        {
            if (TINY.SubT == TinyType.TINY_AXC)
            {
                try
                {
                    if (LayoutName != "None")
                    {
                        insim.Send(255, "^8Layout removed");

                    }
                    else
                    {
                        LayoutName = "None";
                    }
                }
                catch (Exception EX) { LogTextToFile("packetError", "AXC - " + EX.Message); }
            }
        }

        CarFlags CarToPLC(string CarName)
        {
            switch (CarName.ToUpper())
            {
                case "UF1": return CarFlags.UF1;
                case "XFG": return CarFlags.XFG;
                case "XRG": return CarFlags.XRG;
                case "LX4": return CarFlags.LX4;
                case "LX6": return CarFlags.LX6;
                case "RB4": return CarFlags.RB4;
                case "FXO": return CarFlags.FXO;
                case "XRT": return CarFlags.XRT;
                case "RAC": return CarFlags.RAC;
                case "FZ5": return CarFlags.FZ5;
                case "UFR": return CarFlags.UFR;
                case "XFR": return CarFlags.XFR;
                case "FXR": return CarFlags.FXR;
                case "XRR": return CarFlags.XRR;
                case "FZR": return CarFlags.FZR;
                case "MRT": return CarFlags.MRT;
                case "FBM": return CarFlags.FBM;
                case "FOX": return CarFlags.FOX;
                case "FO8": return CarFlags.FO8;
                case "BF1": return CarFlags.BF1;

            }
            return CarFlags.None;
        }

        bool CheckCars(byte UCID)
        {
            string[] AllCars = AVAILABLE_CARS.Split('+');
            CarFlags AvailableCars = CarFlags.None;
            string CurrentCar = "";
            bool DrivingNotOwnedCar = true;

            byte PlayerID = GetPlayer(UCID);
            if (PlayerID != 255) CurrentCar = _players[PlayerID].CName;

            foreach (var ThisCar in AllCars)
            {
                if (_connections[UCID].cars.Contains(ThisCar))
                {
                    if (ThisCar == CurrentCar) DrivingNotOwnedCar = false;
                    AvailableCars |= CarToPLC(ThisCar);
                }
            }

            insim.Send(new IS_PLC { UCID = UCID, Cars = AvailableCars });
            return DrivingNotOwnedCar;
        }

        void ClearPen(string Username) { insim.Send("/p_clear " + Username); }

        void KickID(string Username) { insim.Send("/kick " + Username); }

        private void btn(string text, byte height, byte width, byte top, byte length, ButtonStyles bstyle, byte clickid, byte ucid)
        {
            insim.Send(new IS_BTN
            {
                Text = text,
                UCID = ucid,
                ReqI = clickid,
                ClickID = clickid,
                BStyle = bstyle,
                H = height,
                W = width,
                T = top,
                L = length
            });
        }

        byte GetPlayer(byte UCID)
        {//Get Player from UCID
            byte PLID = 255;
            foreach (var CurrentPlayer in _players.Values) if (CurrentPlayer.UCID == UCID) PLID = CurrentPlayer.PLID;

            return PLID;
        }

        private Connections GetConnection(byte PLID)
        {//Get Connection from PLID
            Players NPL;
            if (_players.TryGetValue(PLID, out NPL)) return _connections[NPL.UCID];
            return null;
        }

        private bool IsConnAdmin(Connections Conn)
        {//general admin check, both Server and InSim
            if (Conn.IsAdmin == true || Conn.IsSuperAdmin == true) return true;
            return false;
        }

        private bool GetUserAdmin(string Username)
        {//reading admins.ini when connecting to server for InSim admin
            StreamReader CurrentFile = new StreamReader("files/admins.ini");

            string line = null;
            while ((line = CurrentFile.ReadLine()) != null)
            {
                if (line == Username)
                {
                    CurrentFile.Close();
                    return true;
                }
            }
            CurrentFile.Close();
            return false;
        }

        private void LogTextToFile(string file, string text, bool AdminMessage = true)
        {

            if (System.IO.File.Exists("files/" + file + ".log") == false) { FileStream CurrentFile = System.IO.File.Create("files/" + file + ".log"); CurrentFile.Close(); }

            StreamReader TextTempData = new StreamReader("files/" + file + ".log");
            string TempText = TextTempData.ReadToEnd();
            TextTempData.Close();

            StreamWriter TextData = new StreamWriter("files/" + file + ".log");
            TextData.WriteLine(TempText + DateTime.Now + ": " + text);
            TextData.Flush();
            TextData.Close();
        }

        #endregion

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (var cenn in _connections.Values)
            {
                if (ConnectedToSQL)
                {
                    try { SqlInfo.UpdateUser(_connections[cenn.UCID].UName, false, _connections[cenn.UCID].cash, _connections[cenn.UCID].bankbalance, _connections[cenn.UCID].TotalDistance, _connections[cenn.UCID].cars, _connections[cenn.UCID].totaljobsdone, _connections[cenn.UCID].totalearnedfromjobs, _connections[cenn.UCID].Timezone); }
                    catch (Exception EX)
                    {
                        if (!SqlInfo.IsConnectionStillAlive())
                        {
                            ConnectedToSQL = false;
                            SQLReconnectTimer.Start();
                        }
                        LogTextToFile("sqlerror", "[" + cenn.UCID + "] " + StringHelper.StripColors(_connections[cenn.UCID].PName) + "(" + _connections[cenn.UCID].UName + ") CNL - Exception: " + EX.Message, false);
                    }
                }
            }
        }

        private void deleteBtn(byte ucid, byte reqi, bool sendbfn, byte clickid)
        {
            if (sendbfn == true)
            {
                IS_BFN bfn = new IS_BFN();
                bfn.ClickID = clickid;
                bfn.UCID = ucid;
                bfn.ReqI = reqi;

                insim.Send(bfn);
            }
        }

        private int AbsoluteAngleDifference(int d, int h)
        {
            d /= 180;
            h /= 180;
            int absdiff = Math.Abs(d - h);

            if (absdiff <= 180) return absdiff;

            if (d < 180)
            {
                h -= 360;
                return d - h;
            }
            else
            {
                d -= 360;
                return h - d;
            }
        }

        private void MessageToAdmins(string Message)
        {
            foreach (var conn in _connections.Values)
            {
                if (conn.IsAdmin == true)
                {
                    if (conn.UName != "")
                    {
                        insim.Send(conn.UCID, 0, "^3Admin notice: ^8" + Message);
                    }
                }
            }
        }
    }
}
