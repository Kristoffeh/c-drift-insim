﻿using System;
using InSimDotNet.Helpers;
using InSimDotNet.Packets;

namespace Derp_InSim
{
    public partial class Form1
    {
        private void BTC_ClientClickedButton(IS_BTC BTC)
        {
            try
            {
                // DELETE a buton:

                // deleteBtn(Ucid, Reqi, true, ClickID);

                // deleteBtn(BTC.UCID, BTC.ReqI, true, 6);
                {

                    switch (BTC.ClickID)
                    {
                        case 6:

                            break;
                    }
                }
            }
            catch (Exception e) { LogTextToFile("error", "[" + BTC.UCID + "] " + StringHelper.StripColors(_connections[BTC.UCID].PName) + "(" + _connections[BTC.UCID].UName + ") - BTC - Exception: " + e, false); }
        }
    }
}
