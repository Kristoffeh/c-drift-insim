﻿using System;
using System.Windows.Forms;
using InSimDotNet;
using InSimDotNet.Packets;
using InSimDotNet.Helpers;

namespace Derp_InSim
{
    public partial class Form1
    {
        private void MessageReceived(InSim insim, IS_MSO mso)
        {
            try
            {
                {

                    if (mso.UserType == UserType.MSO_PREFIX)
                    {
                        string Text = mso.Msg.Substring(mso.TextStart, (mso.Msg.Length - mso.TextStart));
                        string[] command = Text.Split(' ');
                        command[0] = command[0].ToLower();

                        switch (command[0])
                        {
                            case "!ac":
                                {//Admin chat
                                    if (mso.UCID == _connections[mso.UCID].UCID)
                                    {
                                        if (!IsConnAdmin(_connections[mso.UCID]))
                                        {
                                            insim.Send(mso.UCID, 0, "You are not an admin");
                                            break;
                                        }
                                        if (command.Length == 1)
                                        {
                                            insim.Send(mso.UCID, 0, "^1Invalid command format. ^2Usage: ^7!ac <text>");
                                            break;
                                        }

                                        string atext = Text.Remove(0, command[0].Length + 1);

                                        foreach (var Conn in _connections.Values)
                                        {
                                            {
                                                if (IsConnAdmin(Conn) && Conn.UName != "")
                                                {
                                                    insim.Send(Conn.UCID, 0, "^3Admin chat: ^7" + _connections[mso.UCID].PName + " ^8(" + _connections[mso.UCID].UName + "):");
                                                    insim.Send(Conn.UCID, 0, "^7" + atext);
                                                }
                                            }
                                        }
                                    }

                                    break;
                                }

                            case "!pos":

                                if (_connections[mso.UCID].IsAdmin == false)
                                {
                                    insim.Send(mso.UCID, "^1Error: ^7You are not an Admin!");
                                    break;
                                }
                                if (AskedPosition == true)
                                {
                                    insim.Send(mso.UCID, "^1Error: ^7Someone else already wants their position, please try again.");
                                    break;
                                }

                                //position @ MCI Packet
                                AskedPosUCID = mso.UCID;
                                AskedPosition = true;
                                break;

                            case "!teamspeak":
                            case "!ts":

                                insim.Send(mso.UCID, "^7Teamspeak 3 Server: ^3" + "ts.eugaming.org");

                                break;

                            case "!ban":
                                var k = _connections[mso.UCID];
                                insim.Send(255, "^1Added ^7" + k.PName + " ^1to the ban list!");
                                insim.Send("/kick " + k.UName);
                                SqlInfo.AddtoBanlist(k.UName, StringHelper.StripColors(k.PName), "14.01.2016", "no longer welcome");
                                break;

                            case "!help":
                                insim.Send(mso.UCID, 0, "^3Help commands (temporary list):");
                                insim.Send(mso.UCID, 0, "^7!help ^8- See a list of available commands");
                                insim.Send(mso.UCID, 0, "^7!info ^8- See a few lines of server info");
                                insim.Send(mso.UCID, 0, "^7!showoff (!show) ^8- Show your stats to everyone connected to the server");


                                // Admin commands
                                foreach (var CurrentConnection in _connections.Values)
                                {
                                    if (CurrentConnection.UCID == mso.UCID)
                                    {
                                        if (IsConnAdmin(CurrentConnection) && CurrentConnection.UName != "")
                                        {
                                            insim.Send(CurrentConnection.UCID, 0, "^3Administrator commands:");
                                            insim.Send(CurrentConnection.UCID, 0, "^7!ac ^8- Talk with the other admins that are online");
                                        }
                                    }
                                }

                                break;

                            case "!info":

                                int count = _connections.Count - 1;

                                insim.Send(mso.UCID, 0, "^3Server Info (temporary list):");
                                insim.Send(mso.UCID, 0, "^8Current track: ^2" + TrackHelper.GetFullTrackName(TrackName) + " ^7(" + TrackName + ")");
                                insim.Send(mso.UCID, 0, "^8Players connected: ^2" + count);
                                insim.Send(mso.UCID, 0, "^8Players on the track: ^2" + _players.Count);
                                insim.Send(mso.UCID, 0, "^8Users registered: ^2" + dbCount);
                                break;

                            case "!s":
                                foreach (var CurrentPlayer in _players.Values)
                                {
                                    if (CurrentPlayer.UCID == mso.UCID) insim.Send(mso.UCID, "^8Current speed: ^3{0} ^8kmh, ^3{1} ^8mph", CurrentPlayer.kmh, CurrentPlayer.mph);
                                }
                                break;

                            case "!show":
                            case "!showoff":
                            case "!stats":
                                foreach (var conn in _connections.Values)
                                {
                                    if (conn.UCID == mso.UCID)
                                    {
                                        insim.Send(255, "^6Showoff for ^7" + _connections[mso.UCID].PName + " ^6(^7" + _connections[mso.UCID].UName + "^6)");
                                        insim.Send(255, "^6Cash: ^2€" + string.Format("{0:n0}", conn.cash));
                                        insim.Send(255, "^6Bankbalance: ^2€" + string.Format("{0:n0}", conn.bankbalance));
                                        insim.Send(255, "^6Total distance driven: ^7" + string.Format("{0:n0}", conn.TotalDistance / 1000) + " kms^6/^7" + string.Format("{0:n0}", conn.TotalDistance / 1609) + " mi");
                                        insim.Send(255, "^6Cars owned: ^7" + _connections[mso.UCID].cars);
                                        insim.Send(255, "^6Jobs completed: ^7" + string.Format("{0:n0}", _connections[mso.UCID].totaljobsdone));
                                        insim.Send(255, "^6Cash earned from jobs: ^2€" + string.Format("{0:n0}", _connections[mso.UCID].totalearnedfromjobs));
                                        insim.Send(255, "^6Last seen: ^7" + _connections[mso.UCID].lastseen);
                                        insim.Send(255, "^6Registration date: ^7" + _connections[mso.UCID].regdate);
                                    }
                                }
                                break;

                            case "!gmt":

                                var connn = _connections[mso.UCID];
                                if (command.Length == 1)
                                {
                                    insim.Send(mso.UCID, "^1Invalid command. ^7Usage: ^3!gmt <timezone>");
                                }
                                else if (command.Length == 2)
                                {
                                    #region ' Command '
                                    if (command[1] == "-12" || command[1] == "-12:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -12");
                                        connn.Timezone = -12;
                                    }
                                    else if (command[1] == "-11" || command[1] == "-11:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -11;
                                    }
                                    else if (command[1] == "-10" || command[1] == "-10:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -10;
                                    }
                                    else if (command[1] == "-9" || command[1] == "-9:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -9;
                                    }
                                    else if (command[1] == "-8" || command[1] == "-8:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -8;
                                    }
                                    else if (command[1] == "-7" || command[1] == "-7:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -7;
                                    }
                                    else if (command[1] == "-6" || command[1] == "-6:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -6;
                                    }
                                    else if (command[1] == "-5" || command[1] == "-5:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -5;
                                    }
                                    else if (command[1] == "-4" || command[1] == "-4:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -4;
                                    }
                                    else if (command[1] == "-3" || command[1] == "-3:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -3;
                                    }
                                    else if (command[1] == "-2" || command[1] == "-2:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -2;
                                    }
                                    else if (command[1] == "-1" || command[1] == "-1:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT -11");
                                        connn.Timezone = -1;
                                    }
                                    else if (command[1] == "0" || command[1] == "0:00" || command[1] == "+0" || command[1] == "+0:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "1" || command[1] == "1:00" || command[1] == "+1" || command[1] == "+1:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT +1");
                                        connn.Timezone = -1;
                                    }
                                    else if (command[1] == "2" || command[1] == "2:00" || command[1] == "+2" || command[1] == "+2:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "GMT +2");
                                        connn.Timezone = 2;
                                    }
                                    else if (command[1] == "3" || command[1] == "3:00" || command[1] == "+3" || command[1] == "+3:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "4" || command[1] == "4:00" || command[1] == "+4" || command[1] == "+4:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "5" || command[1] == "5:00" || command[1] == "+5" || command[1] == "+5:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "6" || command[1] == "6:00" || command[1] == "+6" || command[1] == "+6:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "7" || command[1] == "7:00" || command[1] == "+7" || command[1] == "+7:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "8" || command[1] == "8:00" || command[1] == "+8" || command[1] == "+8:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "9" || command[1] == "9:00" || command[1] == "+9" || command[1] == "+9:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "10" || command[1] == "10:00" || command[1] == "+10" || command[1] == "+10:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "11" || command[1] == "11:00" || command[1] == "+11" || command[1] == "+11:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    else if (command[1] == "12" || command[1] == "12:00" || command[1] == "+12" || command[1] == "+12:00")
                                    {
                                        insim.Send(mso.UCID, "^8Your timezone has been set to ^3" + "default (GMT)");
                                        connn.Timezone = 0;
                                    }
                                    #endregion

                                }
                                break;

                            default:
                                insim.Send(mso.UCID, 0, "^8Invalid command, type {0} to see available commands", "^2!help^8");
                                break;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("" + e, "AN ERROR OCCURED");
                insim.Send(255, "^8An error occured: ^1{0}", e);
            }
        }
    }

}
